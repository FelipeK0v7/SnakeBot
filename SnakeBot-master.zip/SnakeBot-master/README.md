# SnakeBot
um bot que joga o classico jogo da cobrinha
